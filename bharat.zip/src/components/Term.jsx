import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

function Term() {
  return (
    <div>
        <Header/>

        <section>
            <h1 className='text-center' style={{height: "50vh"}}>Term and condition</h1>
        </section>

        <Footer/>
    </div>
  )
}

export default Term